package com.daybuddy.app

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDate

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("daybuddy", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders", true)) return
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val today = LocalDate.now()
        val custom = (prefs.getString("custom", "") ?: "").lineSequence().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|", limit = 2)
            if (p.size != 2) null else try { DayItem(LocalDate.parse(p[0]), p[1], "💗", "", true) } catch (_: Exception) { null }
        }.toList()
        val items = SpecialDays.itemsFor(today, custom)
        val title: String
        val message: String
        if (items.isEmpty()) {
            title = "A new day, a little sparkle ✨"
            message = "Check DayBuddy for upcoming celebrations and your personal dates."
        } else {
            title = "Today's special day 💗"
            message = items.joinToString(" · ") { "${it.emoji} ${it.title}" }
        }
        val open = PendingIntent.getActivity(context, 2002, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, "daybuddy_daily")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(open).setAutoCancel(true).build()
        NotificationManagerCompat.from(context).notify(2003, notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED && context.getSharedPreferences("daybuddy", Context.MODE_PRIVATE).getBoolean("reminders", true)) {
            MainActivity.scheduleDailyReminder(context)
        }
    }
}
