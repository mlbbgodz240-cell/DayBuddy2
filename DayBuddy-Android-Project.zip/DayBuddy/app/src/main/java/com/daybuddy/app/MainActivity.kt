package com.daybuddy.app

import android.Manifest
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("daybuddy", Context.MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private val pink = 0xFFD94F91.toInt()
    private val ink = 0xFF392532.toInt()
    private val muted = 0xFF806D79.toInt()
    private val bg = 0xFFFFF8FB.toInt()
    private val pale = 0xFFFFE5F0.toInt()
    private var selectedDate: LocalDate = LocalDate.now()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        requestNotificationPermission()
        buildScreen()
        if (prefs.getBoolean("reminders", true)) scheduleDailyReminder(this)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(30))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        render()
    }

    private fun render() {
        content.removeAllViews()
        val today = LocalDate.now()
        addText("daybuddy ✿", 27f, pink, true, 0, 0, 0, 2)
        addText(today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault())), 14f, muted, false, 0, 0, 0, 18)

        val todays = SpecialDays.itemsFor(today, customDays())
        val hero = card(pale, 24)
        hero.addView(text("TODAY'S LITTLE REMINDER", 11f, pink, true))
        hero.addView(text(today.dayOfMonth.toString(), 62f, ink, true).apply { setPadding(0, dp(3), 0, 0) })
        if (todays.isEmpty()) {
            hero.addView(text("A fresh page 🌷", 22f, ink, true))
            hero.addView(text("No celebration in our calendar today. Add your own reason to celebrate!", 14f, muted, false))
        } else {
            todays.forEach { item ->
                hero.addView(text("${item.emoji}  ${item.title}", 20f, ink, true).apply { setPadding(0, dp(2), 0, dp(5)) })
                hero.addView(text(item.note, 14f, muted, false).apply { setPadding(0, 0, 0, dp(6)) })
            }
        }
        hero.addView(button("Check another date  ✨") { showDatePicker() }.apply { setTextColor(pink) })
        content.addView(hero, matchWrap(0, 15))

        addText("Coming up", 21f, ink, true, 0, 3, 0, 8)
        val upcoming = SpecialDays.upcoming(today, customDays(), 12)
        if (upcoming.isEmpty()) addText("Your calendar is waiting for a little sparkle.", 14f, muted, false, 0, 0, 0, 12)
        upcoming.forEach { item ->
            val row = card(0xFFFFFFFF.toInt(), 18)
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            line.addView(text(item.emoji, 27f, ink, false), LinearLayout.LayoutParams(dp(42), -2))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(text(item.title, 15f, ink, true))
            details.addView(text(SpecialDays.dateLabel(item.date) + if (item.personal) " · your date" else "", 12f, muted, false))
            line.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(line)
            content.addView(row, matchWrap(0, 8))
        }

        addText("Your dates 💌", 21f, ink, true, 0, 12, 0, 8)
        addText("Birthdays, anniversaries, inside jokes, anything worth remembering.", 13f, muted, false, 0, 0, 0, 10)
        content.addView(button("＋  Add a special date") { addCustomDate() }, matchWrap(0, 8))
        val customs = customDays()
        if (customs.isEmpty()) {
            addText("Your personal dates will show up here.", 13f, muted, false, 0, 2, 0, 10)
        } else customs.sortedBy { daysUntil(it.date, today) }.forEach { item ->
            val row = card(0xFFFFFFFF.toInt(), 16)
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val detail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            detail.addView(text("${item.emoji}  ${item.title}", 15f, ink, true))
            detail.addView(text("${item.date.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault()))} · every year", 12f, muted, false))
            line.addView(detail, LinearLayout.LayoutParams(0, -2, 1f))
            val remove = Button(this).apply {
                text = "Remove"; textSize = 11f; setTextColor(pink); isAllCaps = false
                setOnClickListener { removeCustom(item); render() }
            }
            line.addView(remove)
            row.addView(line)
            content.addView(row, matchWrap(0, 7))
        }

        addText("Reminder settings 🔔", 21f, ink, true, 0, 14, 0, 8)
        val settings = card(0xFFFFFFFF.toInt(), 18)
        val switch = Switch(this).apply {
            text = "Daily special day reminder"
            textSize = 15f
            setTextColor(ink)
            isChecked = prefs.getBoolean("reminders", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("reminders", checked).apply()
                if (checked) {
                    requestNotificationPermission()
                    scheduleDailyReminder(this@MainActivity)
                    Toast.makeText(this@MainActivity, "Daily reminder enabled", Toast.LENGTH_SHORT).show()
                } else {
                    cancelDailyReminder(this@MainActivity)
                    Toast.makeText(this@MainActivity, "Daily reminder paused", Toast.LENGTH_SHORT).show()
                }
            }
        }
        settings.addView(switch)
        val time = prefs.getString("time", "09:00") ?: "09:00"
        settings.addView(text("Reminder time · $time", 13f, muted, false).apply { setPadding(0, dp(5), 0, dp(8)) })
        settings.addView(button("Change reminder time") {
            val parts = time.split(":")
            TimePickerDialog(this, { _, hour, minute ->
                val newTime = String.format(Locale.US, "%02d:%02d", hour, minute)
                prefs.edit().putString("time", newTime).apply()
                if (prefs.getBoolean("reminders", true)) scheduleDailyReminder(this)
                render()
            }, parts[0].toInt(), parts[1].toInt(), false).show()
        })
        content.addView(settings, matchWrap(0, 18))
        addText("Made with a little love ♡  ·  DayBuddy works offline", 12f, muted, false, 0, 6, 0, 4)
    }

    private fun showDatePicker() {
        val now = LocalDate.now()
        DatePickerDialog(this, { _, year, month, day ->
            selectedDate = LocalDate.of(year, month + 1, day)
            val found = SpecialDays.itemsFor(selectedDate, customDays())
            val message = if (found.isEmpty()) "Nothing in the calendar yet. Want to add your own date?" else found.joinToString("\n\n") { "${it.emoji} ${it.title}\n${it.note}" }
            AlertDialog.Builder(this).setTitle("${selectedDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.getDefault()))} 🌸")
                .setMessage(message)
                .setPositiveButton(if (found.isEmpty()) "Add this date" else "Lovely") { _, _ -> if (found.isEmpty()) addCustomDate(selectedDate) }
                .setNegativeButton("Close", null).show()
        }, now.year, now.monthValue - 1, now.dayOfMonth).show()
    }

    private fun addCustomDate(initial: LocalDate = LocalDate.now()) {
        val input = android.widget.EditText(this).apply { hint = "e.g. Bestie's birthday"; setSingleLine(true) }
        var picked = initial
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0) }
        wrap.addView(input)
        val dateButton = Button(this).apply {
            text = "Date: ${picked.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault()))}"
            isAllCaps = false
            setOnClickListener {
                val d = picked
                DatePickerDialog(this@MainActivity, { _, y, m, day ->
                    picked = LocalDate.of(y, m + 1, day)
                    text = "Date: ${picked.format(DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault()))}"
                }, d.year, d.monthValue - 1, d.dayOfMonth).show()
            }
        }
        wrap.addView(dateButton)
        AlertDialog.Builder(this).setTitle("Add your special date 💗").setView(wrap)
            .setPositiveButton("Save") { _, _ ->
                val title = input.text.toString().trim()
                if (title.isNotBlank()) {
                    val all = customDays().toMutableList()
                    all.add(DayItem(picked, title.replace("|", " "), "💗", "A little reminder from you to you.", true))
                    saveCustom(all)
                    render()
                    Toast.makeText(this, "Date saved ✨", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Add a name for your date first", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun customDays(): List<DayItem> = (prefs.getString("custom", "") ?: "").lineSequence()
        .filter { it.isNotBlank() }
        .mapNotNull { line ->
            val parts = line.split("|", limit = 2)
            if (parts.size != 2) null else try { DayItem(LocalDate.parse(parts[0]), parts[1], "💗", "A personal date to remember.", true) } catch (_: Exception) { null }
        }.toList()

    private fun saveCustom(items: List<DayItem>) {
        prefs.edit().putString("custom", items.joinToString("\n") { "${it.date}|${it.title.replace("\n", " ")}" }).apply()
    }

    private fun removeCustom(item: DayItem) { saveCustom(customDays().filterNot { it.date == item.date && it.title == item.title }) }

    private fun daysUntil(date: LocalDate, today: LocalDate): Long {
        var next = date.withYear(today.year)
        if (next.isBefore(today)) next = next.plusYears(1)
        return java.time.temporal.ChronoUnit.DAYS.between(today, next)
    }

    private fun card(color: Int, radius: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(15), dp(17), dp(15))
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.START
    }

    private fun addText(value: String, size: Float, color: Int, bold: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        val t = text(value, size, color, bold)
        t.setPadding(dp(left), dp(top), dp(right), dp(bottom))
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(0xFFFFFFFF.toInt())
        background = GradientDrawable().apply { setColor(pink); cornerRadius = dp(16).toFloat() }
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { action() }
    }

    private fun matchWrap(bottom: Int = 0, top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("daybuddy_daily", "Daily special day reminders", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "A gentle reminder of today's special days"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
        }
    }

    companion object {
        fun scheduleDailyReminder(context: Context) {
            val prefs = context.getSharedPreferences("daybuddy", Context.MODE_PRIVATE)
            val parts = (prefs.getString("time", "09:00") ?: "09:00").split(":")
            val hour = parts[0].toIntOrNull() ?: 9
            val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val now = java.time.ZonedDateTime.now()
            var next = now.toLocalDate().atTime(hour, minute).atZone(ZoneId.systemDefault())
            if (!next.isAfter(now)) next = next.plusDays(1)
            val intent = Intent(context, ReminderReceiver::class.java)
            val pending = PendingIntent.getBroadcast(context, 2001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.toInstant().toEpochMilli(), AlarmManager.INTERVAL_DAY, pending)
        }
        fun cancelDailyReminder(context: Context) {
            val pending = PendingIntent.getBroadcast(context, 2001, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
        }
    }
}
